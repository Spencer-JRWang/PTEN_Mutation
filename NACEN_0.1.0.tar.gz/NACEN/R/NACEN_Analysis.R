#'@title Network Analysis for NACEN
#'@description Performs network analysis for node-weighted amino acids contact energy network
#' @param AM an adjacency matrix of the amino acid network
#' @param NodeWeights a vector of node weights for each residue of protein
#' @return \code{OutNetP} a list containing the network parameters and edges list
#' @export

NACENAnalyzer <- function(AM,NodeWeights){
  G<-igraph::graph.adjacency(data.matrix(AM), mode="undirected")
  B<-igraph::betweenness(G,directed = FALSE)
  K<-igraph::degree(G)
  C<-igraph::closeness(G)
  Tr<-igraph::transitivity(G,type="local")

  Kw <- ParametersNormal(K)*NodeWeights
  Bw <- ParametersNormal(B)*NodeWeights
  Cw <- ParametersNormal(C)*NodeWeights
  Tw <- (1-ParametersNormal(Tr))*NodeWeights

  Resinfor<-t(data.frame(strsplit(colnames(AM),split = ":")))
  colnames(Resinfor) <- c("chain","Resid","Res")
  rownames(Resinfor) <- NULL
  NetP <- data.frame(ID=colnames(AM),Resinfor,K,B,C,Tr,Kw,Bw,Cw,Tw)

  Edges <- igraph::get.edgelist(G)#prepared Edgelist for Cytoscape

  OutNetP <- list(NetP=NetP,Edgelist=Edges)
  return(OutNetP)
}


#'@title Network visualization for NACEN
#'@description Plot the node-weighted amino acids contact energy network
#' @param NACEN an list object from NACENConstructor function
#' @export

plotNACEN <- function(NACEN){
  if (nrow(NACEN$AM) < 1000){
    G<-igraph::graph.adjacency(data.matrix(NACEN$AM), mode="undirected")
    minC <- rep(-Inf, igraph::vcount(G))
    maxC <- rep(Inf, igraph::vcount(G))
    minC[1] <- maxC[1] <- 0
    x <- igraph::layout_with_fr(G, minx=minC, maxx=maxC,miny=minC, maxy=maxC)

    #grDevices::pdf(file = paste(getwd(),"/NACENPlot.pdf",sep=''))
    igraph::plot.igraph(G,layout=x, vertex.size=(NACEN$NodeWeights)*200,vertex.label.cex=0.2,vertex.frame.color=NA,
                        vertex.color= "red", rescale=F, xlim=range(x[,1]), ylim=range(x[,2]))
    #grDevices::dev.off()
    #print("The network figure is saved in your current working directory")
  }else {
    print("The network is too large to plot.")
  }
}
