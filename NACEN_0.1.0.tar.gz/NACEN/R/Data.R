#' Contact Energy Parameters
#'
#' A dataset containing environment-dependent residue contact energies.
#' The energy parameters are divided into six groups, AA, BB, AB, AC, BC, and CC,
#' where A, B, and C represent helix, strand, and coil states, respectively.
#'
#' @format A list with 6 matrix:
#' \describe{
#'   \item{AA}{alpha-alpha secondary structure}
#'   \item{BB}{beta-beta secondary structure}
#'   \item{CC}{loop-loop secondary structure}
#'   \item{AC}{alpha-loop secondary structure}
#'   \item{AB}{alpha-beta secondary structure}
#'   \item{BC}{beta-alpha secondary structure}
#' }

"EnergyParameters"
if(getRversion() >= "3.1.0") utils::globalVariables("EnergyParameters")
