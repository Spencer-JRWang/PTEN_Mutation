#' @title Normalize Parameters
#' @description Normalize the parameters to 0-1
#' @param v a vector of data values
#' @return \code{u} the vector of normalized v
#' @export
ParametersNormal<-function(v){
  if (length(which(is.na(v)))>=1) v[which(is.na(v))]=0
  u<-(v-min(v))/(max(v)-min(v))
  return(u)
}

#' @title Contact Energy
#' @description Calculate the contact energy between residues in a protein
#' @param PDBFile a PDB file address name to be read, or the four letter PDB identifier for online file access.
#' @param ResidueDis  the maximum distance between two residue C_alpha atom
#' @param exefile file path to DSSP program on your system
#' @return
#' \code{Energy}  a dataframe containing the contact energy between residues
#' @export
ContactEnergy <- function(PDBFile,ResidueDis=7,exefile){
  PDB2 <- bio3d::read.pdb(PDBFile,rm.insert=TRUE, rm.alt=TRUE)#load PDB file
  PDB <- bio3d::trim(PDB2, 'protein')
  #analysis PDB
  ca.inds <- bio3d::atom.select(PDB, "calpha")#select the C_alpha index
  C_alpha <- PDB$atom[ca.inds$atom, ]#get the xyz and b-factor

  #second structure analysis and accessibility wtih DSSP

  suppressWarnings(dsspFile <- bio3d::dssp(PDB,exefile = exefile))

  dsspPDBinform <- matrix(unlist(strsplit(names(dsspFile$sse),split = "_")),ncol = 3,byrow = T)[,1:2]
  PDBDssp <- data.frame(SS=unlist(dsspFile$sse),ACC=unlist(dsspFile$acc),Phi=unlist(dsspFile$phi),PSi=unlist(dsspFile$psi),chain=dsspPDBinform[,2],resno=dsspPDBinform[,1])
  PDBDssp$SS <- as.vector(PDBDssp$SS)
  MissSS <- which(PDBDssp$SS==" ")
  PDBDssp$SS[MissSS] <- as.vector(rep('X',length(MissSS)))#supplement the missing second structure as "X"

  #delete the missing residues according to the DSSP
  chains <- unique(PDBDssp$chain)
  AllMissIndex <- NULL
  MissRes <- NULL
  for (s in 1:length(chains)){
    tempmissRes <- setdiff(C_alpha$resno[which(C_alpha$chain==chains[s])],PDBDssp$resno[which(PDBDssp$chain==chains[s])])
    if (length(tempmissRes)>0){
      MissRes <- rbind(MissRes,data.frame(resno=tempmissRes,chain=rep(chains[s],length(tempmissRes))))
    }
  }

  if (is.null(nrow(MissRes))) {
    Index <- 1:nrow(C_alpha)
  }else if (nrow(MissRes) > 0){
    for (s in 1:nrow(MissRes)){
      tempmissIndex <- which(C_alpha$chain==MissRes$chain[s] & C_alpha$resno==MissRes$resno[s])
      AllMissIndex <- c(AllMissIndex,tempmissIndex)
    }
    Index <- (1:nrow(C_alpha))[-AllMissIndex]
  }

  PDBInform <- data.frame(C_alpha[Index,],PDBDssp,stringsAsFactors = F)


  #build the Residue Distance matrix
  DM <- data.matrix(bio3d::dm(PDB,inds="calpha"))[Index,Index]
  ATOMLable <- which(PDBInform$type !="HETATM") #delete the HETATM
  PDBInform <- PDBInform[ATOMLable,]
  DM<- DM[ATOMLable,ATOMLable]

  Energy <- data.frame(which(DM<ResidueDis,arr.ind = T))

  #according the residue second structure from PDBInform, construct the contact energy data frame
  for (s in 1:nrow(Energy)){
    i <- Energy$row[s]
    j <- Energy$col[s]

    iRes <- PDBInform$resid[i]
    jRes <- PDBInform$resid[j]

    if (PDBInform$SS[i]=="H"){
      if (PDBInform$SS[j]=="H"){
        Energy$CE[s] <- EnergyParameters$AA[which(rownames(EnergyParameters$AA)==iRes),which(colnames(EnergyParameters$AA)==jRes)]
      }else if (PDBInform$SS[j]=="E"){
        Energy$CE[s] <- EnergyParameters$AB[which(rownames(EnergyParameters$AB)==iRes),which(colnames(EnergyParameters$AB)==jRes)]
      }else{
        Energy$CE[s] <- EnergyParameters$AC[which(rownames(EnergyParameters$AC)==iRes),which(colnames(EnergyParameters$AC)==jRes)]
      }
    }else if (PDBInform$SS[i]=="E"){
      if (PDBInform$SS[j]=="H"){
        Energy$CE[s] <- EnergyParameters$AB[which(rownames(EnergyParameters$AB)==jRes),which(colnames(EnergyParameters$AB)==iRes)]
      }else if (PDBInform$SS[j]=="E"){
        Energy$CE[s] <- EnergyParameters$BB[which(rownames(EnergyParameters$BB)==iRes),which(colnames(EnergyParameters$BB)==jRes)]
      }
      else{
        Energy$CE[s] <- EnergyParameters$BC[which(rownames(EnergyParameters$BC)==iRes),which(colnames(EnergyParameters$BC)==jRes)]
      }
    }else{
      if (PDBInform$SS[j]=="H"){
        Energy$CE[s] <- EnergyParameters$AC[which(rownames(EnergyParameters$AC)==jRes),which(colnames(EnergyParameters$AC)==iRes)]
      }else if (PDBInform$SS[j]=="E"){
        Energy$CE[s] <- EnergyParameters$BC[which(rownames(EnergyParameters$BC)==jRes),which(colnames(EnergyParameters$BC)==iRes)]
      }else{
        Energy$CE[s] <- EnergyParameters$CC[which(rownames(EnergyParameters$CC)==iRes),which(colnames(EnergyParameters$CC)==jRes)]
      }
    }
  }
  NodeName <- paste(PDBInform$chain,PDBInform$resno,PDBInform$resid,sep=":")
  Energy$ResidueFrom <- NodeName[Energy$row]
  Energy$ResidueTo <- NodeName[Energy$col]
  Energy$Distance <- DM[data.matrix(Energy[,1:2])]
  return(Energy)

}
